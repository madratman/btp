 function f = myfun(x,a1)      
         f = 0;  